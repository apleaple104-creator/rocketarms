package com.menek.rocketarms;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mod.EventBusSubscriber(modid = RocketArms.MODID)
public class CommonEvents {
    /** Pemain yang sedang menyalakan jetpack (diisi dari paket client). */
    public static final Set<UUID> THRUSTING = ConcurrentHashMap.newKeySet();

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) {
            return;
        }
        Player p = e.player;
        if (!THRUSTING.contains(p.getUUID())) {
            return;
        }
        ItemStack chest = p.getItemBySlot(EquipmentSlot.CHEST);
        if (!JetpackItem.hasFuel(chest)) {
            THRUSTING.remove(p.getUUID());
            return;
        }
        p.fallDistance = 0.0F;
        if (p.tickCount % 2 == 0 && !p.getAbilities().instabuild) {
            chest.hurtAndBreak(1, p, pl -> pl.broadcastBreakEvent(EquipmentSlot.CHEST));
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (e.getEntity() instanceof Player p
                && JetpackItem.hasFuel(p.getItemBySlot(EquipmentSlot.CHEST))) {
            e.setDamageMultiplier(0.3F);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        THRUSTING.remove(e.getEntity().getUUID());
    }
}
