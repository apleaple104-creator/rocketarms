package com.menek.rocketarms;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Klik kanan untuk menembakkan Roket (butuh item Roket di inventory). */
public class RocketLauncherItem extends Item {
    public RocketLauncherItem(Properties properties) {
        super(properties);
    }

    private static ItemStack findAmmo(Player player) {
        for (ItemStack s : player.getInventory().items) {
            if (s.is(ModItems.ROKET.get())) {
                return s;
            }
        }
        return ItemStack.EMPTY;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean creative = player.getAbilities().instabuild;
        ItemStack ammo = findAmmo(player);
        if (ammo.isEmpty() && !creative) {
            return InteractionResultHolder.fail(stack);
        }
        if (!level.isClientSide) {
            RocketEntity rocket = new RocketEntity(level, player);
            rocket.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 2.5F, 0.5F);
            level.addFreshEntity(rocket);

            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.2F, 0.8F);

            Vec3 look = player.getLookAngle();
            player.push(-look.x * 0.25D, 0.05D, -look.z * 0.25D);
            player.hurtMarked = true;

            if (!creative) {
                ammo.shrink(1);
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
        }
        player.getCooldowns().addCooldown(this, 30);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
