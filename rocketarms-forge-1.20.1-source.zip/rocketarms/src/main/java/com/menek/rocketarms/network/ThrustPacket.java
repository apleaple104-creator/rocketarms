package com.menek.rocketarms.network;

import com.menek.rocketarms.CommonEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client memberi tahu server bahwa jetpack sedang menyala (untuk mengurangi bahan bakar). */
public record ThrustPacket(boolean thrusting) {
    public static void encode(ThrustPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.thrusting);
    }

    public static ThrustPacket decode(FriendlyByteBuf buf) {
        return new ThrustPacket(buf.readBoolean());
    }

    public static void handle(ThrustPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer sp = c.getSender();
            if (sp != null) {
                if (msg.thrusting) {
                    CommonEvents.THRUSTING.add(sp.getUUID());
                } else {
                    CommonEvents.THRUSTING.remove(sp.getUUID());
                }
            }
        });
        c.setPacketHandled(true);
    }
}
