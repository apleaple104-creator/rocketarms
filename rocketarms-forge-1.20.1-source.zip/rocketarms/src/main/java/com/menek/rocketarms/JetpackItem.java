package com.menek.rocketarms;

import com.menek.rocketarms.client.JetpackModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.function.Consumer;

/** Jetpack di punggung. Tahan tombol lompat untuk terbang. Durability = bahan bakar. */
public class JetpackItem extends ArmorItem {
    public JetpackItem(Properties properties) {
        super(ModArmorMaterial.JETPACK, ArmorItem.Type.CHESTPLATE, properties);
    }

    public static boolean hasFuel(ItemStack stack) {
        return stack.getItem() instanceof JetpackItem && stack.getDamageValue() < stack.getMaxDamage() - 1;
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return RocketArms.MODID + ":textures/models/armor/jetpack.png";
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private JetpackModel model;

            @Override
            public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                                                          EquipmentSlot slot, HumanoidModel<?> original) {
                if (model == null) {
                    model = new JetpackModel(Minecraft.getInstance().getEntityModels().bakeLayer(JetpackModel.LAYER));
                }
                return model;
            }
        });
    }
}
