package com.menek.rocketarms;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RocketArms.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RocketArms.MODID);

    public static final RegistryObject<Item> ROKET = ITEMS.register("roket",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> PELUNCUR_ROKET = ITEMS.register("peluncur_roket",
            () -> new RocketLauncherItem(new Item.Properties().stacksTo(1).durability(300)));

    public static final RegistryObject<Item> TINJU_ROKET = ITEMS.register("tinju_roket",
            () -> new RocketFistItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> JETPACK = ITEMS.register("jetpack",
            () -> new JetpackItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("rocket_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rocketarms"))
                    .icon(() -> new ItemStack(PELUNCUR_ROKET.get()))
                    .displayItems((params, output) ->
                            ITEMS.getEntries().forEach(e -> output.accept(e.get())))
                    .build());
}
