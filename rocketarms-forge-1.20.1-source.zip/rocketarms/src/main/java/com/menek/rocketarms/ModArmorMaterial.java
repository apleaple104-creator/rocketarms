package com.menek.rocketarms;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;

/** Bahan armor Jetpack. Durability = bahan bakar. Isi ulang di anvil dengan Blaze Powder / Coal / Charcoal. */
public enum ModArmorMaterial implements ArmorMaterial {
    JETPACK;

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return 600;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return 3;
    }

    @Override
    public int getEnchantmentValue() {
        return 10;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_IRON;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(Items.BLAZE_POWDER, Items.COAL, Items.CHARCOAL);
    }

    @Override
    public String getName() {
        return RocketArms.MODID + ":jetpack";
    }

    @Override
    public float getToughness() {
        return 1.0F;
    }

    @Override
    public float getKnockbackResistance() {
        return 0.0F;
    }
}
