package com.menek.rocketarms;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.function.Consumer;

/** Tinju roket: pukulan menyodok ke depan, meledak kecil dan melempar musuh. */
public class RocketFistItem extends SwordItem {
    public RocketFistItem(Properties properties) {
        super(Tiers.NETHERITE, 2, -2.0F, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.hurtEnemy(stack, target, attacker);
        Vec3 look = attacker.getLookAngle();
        target.push(look.x * 1.3D, 0.35D, look.z * 1.3D);
        target.hurtMarked = true;
        target.setSecondsOnFire(3);
        if (attacker.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.EXPLOSION, target.getX(), target.getY(0.5D), target.getZ(),
                    1, 0.0D, 0.0D, 0.0D, 0.0D);
            sl.playSound(null, target.getX(), target.getY(), target.getZ(),
                    SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.6F, 1.4F);
        }
        return result;
    }

    /** Animasi pukul orang pertama: tangan menyodok lurus ke depan seperti tinju. */
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public boolean applyForgeHandTransform(PoseStack poseStack, LocalPlayer player, HumanoidArm arm,
                                                   ItemStack itemInHand, float partialTick,
                                                   float equipProcess, float swingProcess) {
                int side = arm == HumanoidArm.RIGHT ? 1 : -1;
                poseStack.translate(side * 0.56F, -0.52F - equipProcess * 0.6F, -0.72F);

                float s = Mth.sin(swingProcess * (float) Math.PI);
                poseStack.translate(-side * 0.15F * s, 0.05F * s, -1.0F * s);
                poseStack.mulPose(Axis.YP.rotationDegrees(side * 25.0F * s));
                poseStack.mulPose(Axis.XP.rotationDegrees(-20.0F * s));
                return true;
            }
        });
    }
}
