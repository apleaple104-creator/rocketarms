package com.menek.rocketarms.client;

import com.menek.rocketarms.JetpackItem;
import com.menek.rocketarms.RocketArms;
import com.menek.rocketarms.RocketFistItem;
import com.menek.rocketarms.network.ModNetwork;
import com.menek.rocketarms.network.ThrustPacket;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RocketArms.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientEvents {
    private static boolean lastSent = false;

    private static void send(boolean thrusting) {
        if (thrusting != lastSent) {
            lastSent = thrusting;
            ModNetwork.CHANNEL.sendToServer(new ThrustPacket(thrusting));
        }
    }

    /** Jetpack: tahan tombol lompat untuk terbang. */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.isPaused()) {
            send(false);
            return;
        }
        ItemStack chest = p.getItemBySlot(EquipmentSlot.CHEST);
        boolean thrust = JetpackItem.hasFuel(chest)
                && mc.options.keyJump.isDown()
                && !p.getAbilities().flying
                && !p.isInWater()
                && !p.isPassenger();
        send(thrust);
        if (!thrust) {
            return;
        }

        Vec3 m = p.getDeltaMovement();
        double vy = Math.min(m.y + 0.16D, 0.5D);
        p.setDeltaMovement(m.x, vy, m.z);
        p.moveRelative(0.05F, new Vec3(p.xxa, 0.0D, p.zza));
        p.fallDistance = 0.0F;

        // api & asap dari nozzle di punggung
        float yaw = p.yBodyRot * Mth.DEG_TO_RAD;
        double bx = p.getX() + Mth.sin(yaw) * 0.35D;
        double bz = p.getZ() - Mth.cos(yaw) * 0.35D;
        for (int i = 0; i < 3; i++) {
            double ox = (p.getRandom().nextDouble() - 0.5D) * 0.3D;
            double oz = (p.getRandom().nextDouble() - 0.5D) * 0.3D;
            p.level().addParticle(ParticleTypes.FLAME, bx + ox, p.getY() + 0.7D, bz + oz, 0.0D, -0.2D, 0.0D);
            p.level().addParticle(ParticleTypes.SMOKE, bx + ox, p.getY() + 0.6D, bz + oz, 0.0D, -0.1D, 0.0D);
        }
    }

    private static float lunge(Player p, float partialTick) {
        if (!(p.getMainHandItem().getItem() instanceof RocketFistItem)) {
            return 0.0F;
        }
        float a = p.getAttackAnim(partialTick);
        return a > 0.0F ? Mth.sin(a * (float) Math.PI) : 0.0F;
    }

    /** Animasi pukul orang ketiga: badan condong menerjang ke depan saat memukul. */
    @SubscribeEvent
    public static void onRenderPlayerPre(RenderPlayerEvent.Pre e) {
        Player p = e.getEntity();
        float s = lunge(p, e.getPartialTick());
        if (s <= 0.0F) {
            return;
        }
        float yaw = Mth.rotLerp(e.getPartialTick(), p.yBodyRotO, p.yBodyRot);
        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(-yaw));
        ps.mulPose(Axis.XP.rotationDegrees(22.0F * s));
        ps.mulPose(Axis.YP.rotationDegrees(yaw));
    }

    @SubscribeEvent
    public static void onRenderPlayerPost(RenderPlayerEvent.Post e) {
        if (lunge(e.getEntity(), e.getPartialTick()) > 0.0F) {
            e.getPoseStack().popPose();
        }
    }
}
