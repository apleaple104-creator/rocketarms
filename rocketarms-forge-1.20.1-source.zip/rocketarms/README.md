# Rocket Arms (Forge 1.20.1)

- Peluncur Roket: klik kanan menembak Roket (ambil dari inventory).
- Tinju Roket: senjata jarak dekat, animasi pukul menyodok ke depan + ledakan kecil.
- Jetpack Roket: pakai di slot dada, tahan tombol lompat untuk terbang.
  Bahan bakar = durability, isi ulang di anvil dengan Blaze Powder / Coal / Charcoal.
